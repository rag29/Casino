Please check out this video tutorial that demonstrates how to use this template in order to create your own holographic icon.
 
http://youtu.be/YSy0VgPKcdQ

Please have in mind that you need a plug-in called "Fuse Layers" from Gimp plugin Registry (http://registry.gimp.org/node/25129 .This amazing plugin will speed up the process. 